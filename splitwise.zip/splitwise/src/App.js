import React, {useState} from 'react';
import Dashboard from './components/Dashboard';
import CreateGroup from './components/CreateGroup';
import AddExpense from './components/AddExpense';
import SettleDebts from './components/SettleDebts';

export default function App(){
  const [view, setView] = useState('dashboard');
  const [selectedGroup, setSelectedGroup] = useState(null);

  return (
    <div className="container py-4">
      <header className="d-flex justify-content-between align-items-center mb-4">
        <h1>SplitWise-lite</h1>
        <nav>
          <button className="btn btn-outline-primary me-2" onClick={()=>setView('dashboard')}>Dashboard</button>
          <button className="btn btn-outline-success me-2" onClick={()=>setView('create')}>Create Group</button>
          <button className="btn btn-outline-secondary" onClick={()=>setView('add')}>Add Expense</button>
        </nav>
      </header>

      <main>
        {view === 'dashboard' && <Dashboard onSelectGroup={(g)=>{setSelectedGroup(g); setView('settle')}}/>}
        {view === 'create' && <CreateGroup onCreated={()=> setView('dashboard')}/>}
        {view === 'add' && <AddExpense onDone={()=> setView('dashboard')} />}
        {view === 'settle' && selectedGroup && <SettleDebts group={selectedGroup} onBack={()=> setView('dashboard') }/>}
      </main>
    </div>
  )
}
